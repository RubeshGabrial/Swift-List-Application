package com.finalProjet.swiftListservice.Service;

import com.finalProjet.swiftListservice.Domain.MyDay;
import com.finalProjet.swiftListservice.Domain.ScheduleTask;
import com.finalProjet.swiftListservice.Domain.User;
import com.finalProjet.swiftListservice.Exception.TaskAlreadyExistException;
import com.finalProjet.swiftListservice.Exception.TaskNotFoundException;
import com.finalProjet.swiftListservice.Exception.UserAlreadyExistsException;
import com.finalProjet.swiftListservice.Exception.UserNotFoundException;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ListService {
    User registerUser(User user)throws UserAlreadyExistsException;
    User getCurrentUserDetails(String userId);
    MyDay createTask(MyDay myDay, String userId) throws TaskAlreadyExistException,UserNotFoundException;
    ResponseEntity<String> deleteTask(String userId, String id)throws TaskNotFoundException,UserNotFoundException;
    List<ScheduleTask>allTask(String userId)throws UserNotFoundException;


    ScheduleTask createSchedule(ScheduleTask scheduleTask,String userId) throws TaskAlreadyExistException,UserNotFoundException;
    ScheduleTask taskUpdate(String userId, String taskId, ScheduleTask scheduleTask) throws UserNotFoundException,TaskAlreadyExistException,TaskNotFoundException;
    ResponseEntity<String> taskDelete(String userId, String taskId)throws TaskNotFoundException,UserNotFoundException;
    List<ScheduleTask>getAllTask(String userId)throws UserNotFoundException;

    ScheduleTask archiveTask(String userId, String taskId)throws TaskNotFoundException, UserNotFoundException;
    ScheduleTask unarchiveTask(String userId, String taskId)throws Exception;
    List<ScheduleTask> getArchivedTaskForUser(String userId) throws TaskNotFoundException, UserNotFoundException;

    ScheduleTask trashed(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException;
    ScheduleTask restoreTaskFromTrash(String userId, String taskId) throws Exception;
    List<ScheduleTask> getRestoredTasksForUser(String userId) throws UserNotFoundException;

    List<ScheduleTask> getTrashedTasks(String userId) throws Exception;

    User getUserById(String userid)throws UserNotFoundException;
}
