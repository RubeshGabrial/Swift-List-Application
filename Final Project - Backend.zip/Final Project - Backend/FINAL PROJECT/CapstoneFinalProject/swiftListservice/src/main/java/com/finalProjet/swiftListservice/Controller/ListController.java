package com.finalProjet.swiftListservice.Controller;


import com.finalProjet.swiftListservice.Domain.MyDay;
import com.finalProjet.swiftListservice.Domain.ScheduleTask;
import com.finalProjet.swiftListservice.Domain.User;
import com.finalProjet.swiftListservice.Exception.TaskAlreadyExistException;
import com.finalProjet.swiftListservice.Exception.TaskNotFoundException;
import com.finalProjet.swiftListservice.Exception.UserAlreadyExistsException;
import com.finalProjet.swiftListservice.Exception.UserNotFoundException;
import com.finalProjet.swiftListservice.Service.ListService;
import com.finalProjet.swiftListservice.Service.ListServiceImpl;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/v2/")
public class ListController {
    private ListServiceImpl listService;
    private ResponseEntity responseEntity;   //private ResponseEntity<?> responseEntity;
    private static final Logger log = LoggerFactory.getLogger(ListController.class);


    @Autowired
    public ListController(ListServiceImpl listService) {
        this.listService = listService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) throws UserAlreadyExistsException {
        try {
            User savedUser = listService.registerUser(user);
            // Wrap the message in an object to ensure it's returned as JSON
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("message", "User with Id " + savedUser.getUserId() + " created successfully"));
        } catch (IllegalArgumentException e) {
            // Similarly, return a JSON object instead of a plain String
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", "User or User ID must not be null"));
        } catch (UserAlreadyExistsException e) {
            // Again, JSON object for consistency
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", "User already exists"));
        }
    }

    @GetMapping("/getUserDetails")
    public ResponseEntity<?> getUserDetails(HttpServletRequest request) {
        String currentUserEmail = (String) request.getAttribute("currentUserEmail");
        return new ResponseEntity<>(listService.getCurrentUserDetails(currentUserEmail), HttpStatus.OK);
    }

    @PostMapping("/user/addList")
    public ResponseEntity<?> saveList(@RequestBody MyDay myDay, HttpServletRequest request) throws UserNotFoundException, TaskAlreadyExistException {

        String userId = null;
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            userId = claims.getSubject();
            MyDay savedList = listService.createTask(myDay, userId);
            return new ResponseEntity<>(savedList, HttpStatus.CREATED);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found with email:" + userId);
        } catch (TaskAlreadyExistException e) {
            throw new TaskAlreadyExistException("Task Already exist");
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
//CREATING TASK FOR SCHEDULE LIST
    @PostMapping("/user/scheduleList")
    public ResponseEntity<?> addTask(@RequestBody ScheduleTask scheduleTask, HttpServletRequest request) throws UserNotFoundException, TaskAlreadyExistException {
        String userId = null;
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            userId = claims.getSubject();
            ScheduleTask addedTask = listService.createSchedule(scheduleTask, userId);
            return new ResponseEntity<>(addedTask, HttpStatus.CREATED);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found with email: " + userId);
        } catch (TaskAlreadyExistException e) {
            throw new TaskAlreadyExistException("Task Already exist");
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    //GET ALL FOR MYDAY
    @GetMapping("/user/task")
    public ResponseEntity<?>getMyDayTask(HttpServletRequest request){
        try{
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            List<ScheduleTask> scheduleTasks = listService.allTask(userId);
            return new ResponseEntity<>(scheduleTasks,HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/user/tasks")
    public ResponseEntity<?> getAllTasks(HttpServletRequest request){
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            List<ScheduleTask> scheduleTasks = listService.getAllTask(userId);
            if (scheduleTasks == null) {
                // Normally, your service should ensure this is never null but an empty list instead.
                scheduleTasks = Collections.emptyList();
            }
            return new ResponseEntity<>(scheduleTasks, HttpStatus.OK);
        } catch (Exception e){
            log.error("Error retrieving all tasks", e); // Good practice to log the exception
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    @GetMapping("/user/{userid}")
    public ResponseEntity<?> getUserById(@PathVariable String userid) {
        try {
            User user = listService.getUserById(userid);
            return ResponseEntity.ok(user);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

//DELETE TASK FOR MYDAY
    @DeleteMapping("/user/task/{id}")
    public ResponseEntity<?> deleteList(@PathVariable String id, HttpServletRequest request) throws TaskNotFoundException, UserNotFoundException {
        String userId = null;
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            userId = claims.getSubject();
            return new ResponseEntity<>(listService.deleteTask(userId, id), HttpStatus.OK);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found with email: " + userId);
        } catch (TaskNotFoundException e) {
            throw new TaskNotFoundException("Task is not there");
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    //DELETE FOR SCHEDULE LIST
    @DeleteMapping("/user/scheduleList/{taskId}")
    public ResponseEntity<?> deleteSchedule(@PathVariable String taskId, HttpServletRequest request) throws TaskNotFoundException, UserNotFoundException {
        String userId = null;
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            userId = claims.getSubject();
            return new ResponseEntity<>(listService.taskDelete(userId, taskId), HttpStatus.OK);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found with email: " + userId);
        } catch (TaskNotFoundException e) {
            throw new TaskNotFoundException("Task is not there");
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PutMapping("/user/archive/{taskId}")
    public ResponseEntity<?> archivedTask(@PathVariable String taskId, HttpServletRequest request){

        try{
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            ScheduleTask archivedTask = listService.archiveTask(userId, taskId);
            return ResponseEntity.ok().body(archivedTask);
        } catch (UserNotFoundException | TaskNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());

        }
    }

    @GetMapping("/user/getArchive")
    public ResponseEntity<List<ScheduleTask>>getArchivedTask(HttpServletRequest request){
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            List<ScheduleTask> archivedTasks = listService.getArchivedTaskForUser(userId);
            return ResponseEntity.ok().body(archivedTasks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }



    @PutMapping("/user/unArchive/{taskId}")
    public ResponseEntity<?>unArchiveTaskes(@PathVariable String taskId,HttpServletRequest request){
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            ScheduleTask unarchivedTask = listService.unarchiveTask(userId, taskId);
            return ResponseEntity.ok().body(unarchivedTask);
        } catch (UserNotFoundException | TaskNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }

    }

    @PutMapping("/user/trash/{taskId}")
    public ResponseEntity<?> moveTrash(@PathVariable String taskId,HttpServletRequest request){
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            ScheduleTask trashedTask = listService.trashed(userId, taskId);
            return ResponseEntity.ok().body(trashedTask);
        } catch (UserNotFoundException | TaskNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }

    }

    @PutMapping("/user/restore/{taskId}")
    public ResponseEntity<?> restoreTrash(@PathVariable String taskId, HttpServletRequest request) {
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            ScheduleTask restoredTask = listService.restoreTaskFromTrash(userId, taskId);
            return ResponseEntity.ok().body(restoredTask);
        } catch (UserNotFoundException | TaskNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    // In ListController.java
    @GetMapping("/user/restored-tasks")
    public ResponseEntity<?> getRestoredTasks(HttpServletRequest request) {
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            List<ScheduleTask> restoredTasks = listService.getRestoredTasksForUser(userId);
            return ResponseEntity.ok().body(restoredTasks);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            log.error("Error retrieving restored tasks", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }


    @GetMapping("/user/tasks/trash")
    public ResponseEntity<List<ScheduleTask>> getTrashed(HttpServletRequest request) {
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            String userId = claims.getSubject();
            List<ScheduleTask> trashedTasks = listService.getTrashedTasks(userId);
            return ResponseEntity.ok().body(trashedTasks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/user/scheduleList/{taskId}")
    public ResponseEntity<?> updateTask(@PathVariable String taskId, @RequestBody ScheduleTask scheduleTask, HttpServletRequest request) throws TaskAlreadyExistException, TaskNotFoundException, UserNotFoundException {
        String userId = null;
        try {
            Claims claims = (Claims) request.getAttribute("claims");
            userId = claims.getSubject();

            ScheduleTask updatedTask = listService.taskUpdate(userId, taskId, scheduleTask);
            updatedTask.setTaskId(taskId);

            return new ResponseEntity<>(updatedTask, HttpStatus.OK);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found with email:" + userId);
        } catch (TaskNotFoundException e) {
            throw new TaskNotFoundException("Task not found");
        } catch (TaskAlreadyExistException e) {
            throw new TaskAlreadyExistException("Task Already Exist");
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }
}


