package com.finalProjet.swiftListservice.Domain;

import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.UUID;

public class MyDay {
    @Id
    private String id;
    private String note;
    private LocalTime time;


    public MyDay(){

    }

    public MyDay(String id, String note, LocalTime time) {
        this.id = UUID.randomUUID().toString();
        this.note = note;
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "MyDay{" +
                "id=" + id +
                ", note='" + note + '\'' +
                ", time=" + time +
                '}';
    }


}
