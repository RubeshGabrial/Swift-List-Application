package com.finalProjet.swiftListservice.Exception;

public class UserNotFoundException extends Exception{
    public UserNotFoundException(String s){
        super(s);
    }
}
