package com.finalProjet.swiftListservice.Exception;

public class TaskNotFoundException extends Exception{
    public TaskNotFoundException(String s){
        super(s);
    }
}
