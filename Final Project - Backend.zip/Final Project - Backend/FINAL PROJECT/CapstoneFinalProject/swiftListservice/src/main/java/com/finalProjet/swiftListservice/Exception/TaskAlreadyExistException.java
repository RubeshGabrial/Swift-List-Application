package com.finalProjet.swiftListservice.Exception;

public class TaskAlreadyExistException extends Exception{
    public TaskAlreadyExistException(String s){
        super(s);
    }

}
