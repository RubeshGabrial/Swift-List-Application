package com.finalProjet.swiftListservice.Domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
public class User {

    @Id
    private String userId;
    private String userName;
    private String password;
    private String gender;
    private String contactNumber;
    private List<MyDay> myDayList;

    private List<ScheduleTask> scheduleTaskList;

    public User(){

    }

    public User(String userId, String userName, String password, String gender, String contactNumber, List<MyDay> myDayList, List<ScheduleTask> scheduleTaskList) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.myDayList = myDayList;
        this.scheduleTaskList = scheduleTaskList;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public List<MyDay> getMyDayList() {
        return myDayList;
    }

    public void setMyDayList(List<MyDay> myDayList) {
        this.myDayList = myDayList;
    }

    public List<ScheduleTask> getScheduleTaskList() {
        return scheduleTaskList;
    }

    public void setScheduleTaskList(List<ScheduleTask> scheduleTaskList) {
        this.scheduleTaskList = scheduleTaskList;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", gender='" + gender + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", myDayList=" + myDayList +
                ", scheduleTaskList=" + scheduleTaskList +
                '}';
    }
}
