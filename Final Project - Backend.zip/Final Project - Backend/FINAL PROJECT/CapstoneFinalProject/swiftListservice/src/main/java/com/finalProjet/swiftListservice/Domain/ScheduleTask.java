package com.finalProjet.swiftListservice.Domain;

import java.time.LocalDate;
import java.time.LocalTime;

public class ScheduleTask {
    private String taskId;
    private String taskName;
    private LocalDate date;
    private LocalTime sTime;
    private String sNote;
    private String taskPriority;

    private boolean isArchived;
    private boolean isTrashed;


    public ScheduleTask(){

    }

    public ScheduleTask(String taskId, String taskName, LocalDate date, LocalTime sTime, String sNote, String taskPriority, boolean isArchived, boolean isTrashed) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.date = date;
        this.sTime = sTime;
        this.sNote = sNote;
        this.taskPriority = taskPriority;
//        this.isArchived = false;
//        this.isTrashed = false;
        this.isArchived = isArchived; // Set using the parameter value
        this.isTrashed = isTrashed;   // Set using the parameter value
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getsTime() {
        return sTime;
    }

    public void setsTime(LocalTime sTime) {
        this.sTime = sTime;
    }

    public String getsNote() {
        return sNote;
    }

    public void setsNote(String sNote) {
        this.sNote = sNote;
    }

    public String getTaskPriority() {
        return taskPriority;
    }

    public void setTaskPriority(String taskPriority) {
        this.taskPriority = taskPriority;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public void setArchived(boolean archived) {
        isArchived = archived;
    }

    public boolean isTrashed() {
        return isTrashed;
    }

    public void setTrashed(boolean trashed) {
        isTrashed = trashed;
    }

    @Override
    public String toString() {
        return "ScheduleTask{" +
                "taskId='" + taskId + '\'' +
                ", taskName='" + taskName + '\'' +
                ", date=" + date +
                ", sTime=" + sTime +
                ", sNote='" + sNote + '\'' +
                ", taskPriority='" + taskPriority + '\'' +
                ", isArchived=" + isArchived +
                ", isTrashed=" + isTrashed +
                '}';
    }
}
