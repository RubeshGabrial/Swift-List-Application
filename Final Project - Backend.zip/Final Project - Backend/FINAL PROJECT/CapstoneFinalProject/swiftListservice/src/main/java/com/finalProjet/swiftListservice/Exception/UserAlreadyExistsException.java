package com.finalProjet.swiftListservice.Exception;

public class UserAlreadyExistsException extends Exception{
    public UserAlreadyExistsException(String s){
        super(s);
    }
}
