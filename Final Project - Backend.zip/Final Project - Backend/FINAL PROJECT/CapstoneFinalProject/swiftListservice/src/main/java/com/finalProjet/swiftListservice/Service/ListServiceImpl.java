package com.finalProjet.swiftListservice.Service;

import com.finalProjet.swiftListservice.Domain.MyDay;
import com.finalProjet.swiftListservice.Domain.ScheduleTask;
import com.finalProjet.swiftListservice.Domain.User;
import com.finalProjet.swiftListservice.Exception.TaskAlreadyExistException;
import com.finalProjet.swiftListservice.Exception.TaskNotFoundException;
import com.finalProjet.swiftListservice.Exception.UserAlreadyExistsException;
import com.finalProjet.swiftListservice.Exception.UserNotFoundException;
import com.finalProjet.swiftListservice.Proxy.UserProxy;
import com.finalProjet.swiftListservice.Repository.UserListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;


import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class ListServiceImpl implements ListService {

    private UserListRepository userListRepository;
    private UserProxy userProxy;
    private PasswordEncoder passwordEncoder;

    @Autowired
    public ListServiceImpl(UserListRepository userListRepository, UserProxy userProxy, PasswordEncoder passwordEncoder) {
        this.userListRepository = userListRepository;
        this.userProxy = userProxy;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User registerUser(User user) throws UserAlreadyExistsException {

        // Check if the user already exists
        if (userListRepository.findById(user.getUserId()).isPresent()) {
            throw new UserAlreadyExistsException("User already exists");
        }
        // Save the user with plain text password (NOT RECOMMENDED)
        User savedUser = userListRepository.save(user);

        // If the username is not empty, save the user using the UserProxy as well
        if (!savedUser.getUserName().isEmpty()) {
            ResponseEntity<?> response = userProxy.saveUser(savedUser);
            System.out.println(response.getBody());
        }
        return savedUser;
    }


    @Override
    public User getCurrentUserDetails(String userId) {
        return userListRepository.findById(userId).get();
    }

    @Override
    public MyDay createTask(MyDay myDay, String userId) throws TaskAlreadyExistException, UserNotFoundException, IllegalArgumentException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email:" + userId);
        }
        User user = optionalUser.get();
        List<MyDay> myDays = user.getMyDayList();
        if (myDays == null) {
            myDays = new ArrayList<>();
        }
        if (myDays.stream().anyMatch(t -> t.getId().equals(myDay.getId()))) {
            throw new TaskAlreadyExistException("User Already exist");
        }
        if (!myDay.getTime().isBefore(LocalTime.now())) {
            myDay.setId(UUID.randomUUID().toString());
            myDays.add(myDay);
            user.setMyDayList(myDays);
            userListRepository.save(user);
            return myDay;
        } else {
            throw new IllegalArgumentException("Time must not be past its must be future");
        }

    }


    @Override
    public ResponseEntity<String> deleteTask(String userId, String id) throws TaskNotFoundException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email:" + userId);
        }
        User user = optionalUser.get();
        List<MyDay> myDays = user.getMyDayList();
        if (myDays == null || myDays.isEmpty()) {
            throw new TaskNotFoundException("Task not found");
        }
        boolean found = false;
        for (MyDay myDay : myDays) {
            if (myDay.getId().equals(id)) {
                myDays.remove(myDay);
                found = true;
            }
        }
        if (!found) {
            throw new TaskNotFoundException("Task is not there");
        }
        user.setMyDayList(myDays);
        userListRepository.save(user);
        return ResponseEntity.ok().body("Task deleted successfully.");
    }


    @Override
    public List<ScheduleTask> allTask(String userId) throws UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        return user.getScheduleTaskList().stream()
                .filter(scheduleTask -> !scheduleTask.isArchived())
                .collect(Collectors.toList());
    }


    @Override
    public ScheduleTask createSchedule(ScheduleTask scheduleTask, String userId) throws TaskAlreadyExistException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email:" + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> scheduleTasks = user.getScheduleTaskList();
        if (scheduleTasks == null) {
            scheduleTasks = new ArrayList<>();
        }
        if (scheduleTasks.stream().anyMatch(t -> t.getTaskId().equals(scheduleTask.getTaskId()))) {
            throw new TaskAlreadyExistException("User Already exist");
        }
        if (!scheduleTask.getDate().isBefore(LocalDate.now())) {

            if (scheduleTask.getTaskPriority() == null) {
                scheduleTask.setTaskPriority("Low");
            }

            scheduleTask.setTaskId(UUID.randomUUID().toString());
            scheduleTasks.add(scheduleTask);
            user.setScheduleTaskList(scheduleTasks);
            userListRepository.save(user);
            return scheduleTask;
        } else {
            throw new IllegalArgumentException("Date should be in the future");
        }

    }

    //SCHEDULE TASK
    @Override
    public ScheduleTask taskUpdate(String userId, String taskId, ScheduleTask scheduleTask) throws UserNotFoundException, TaskAlreadyExistException, TaskNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> scheduleTasks = user.getScheduleTaskList();
        if (scheduleTasks == null || scheduleTasks.isEmpty()) {
            throw new TaskNotFoundException("Task not found");
        }
        boolean taskUpdated = false;
        for (ScheduleTask s : scheduleTasks) {
            if (s.getTaskId().equals(taskId)) {
                s.setTaskName(scheduleTask.getTaskName());
                s.setDate(scheduleTask.getDate());
                s.setsNote(scheduleTask.getsNote());
                s.setTaskPriority(scheduleTask.getTaskPriority());
                taskUpdated = true;
                break;
            }
        }
        if (!taskUpdated) {
            throw new TaskNotFoundException("Task Not Found");
        }
        userListRepository.save(user);
        return scheduleTask;
    }


    @Override
    public ResponseEntity<String> taskDelete(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (!optionalUser.isPresent()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> tasks = user.getScheduleTaskList();
        if (tasks == null || tasks.isEmpty()) {
            throw new TaskNotFoundException("Task not found");
        }
        ScheduleTask taskToRemove = null;
        for (ScheduleTask task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                taskToRemove = task;
                break;
            }
        }
        if (taskToRemove != null) {
            tasks.remove(taskToRemove);
            userListRepository.save(user);
            return ResponseEntity.ok().body("Task deleted successfully.");
        } else {
            throw new TaskNotFoundException("Task Not found");
        }
    }

    @Override
    public List<ScheduleTask> getAllTask(String userId) throws UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        // Filter out archived tasks before returning
        return user.getScheduleTaskList().stream()
                .filter(scheduleTask -> !scheduleTask.isArchived())
                .collect(Collectors.toList());
    }


    @Override
    public ScheduleTask archiveTask(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException {

        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> tasks = user.getScheduleTaskList();
        if (tasks == null || tasks.isEmpty()) {
            throw new TaskNotFoundException("Task not found");
        }
        ScheduleTask taskToArchive = null;
        for (ScheduleTask task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                taskToArchive = task;
                break;
            }
        }
        if (taskToArchive == null) {
            throw new TaskNotFoundException("Task not Found");
        }
        taskToArchive.setArchived(true);

        userListRepository.save(user);
        return taskToArchive;
    }


    @Override
    public ScheduleTask unarchiveTask(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> scheduleTasks = user.getScheduleTaskList();
        if (scheduleTasks == null || scheduleTasks.isEmpty()) {
            throw new TaskNotFoundException("Task not Found");
        }
        ScheduleTask taskToUnarchive = null;
        for (ScheduleTask scheduleTask : scheduleTasks) {
            if (scheduleTask.getTaskId().equals(taskId)) {
                taskToUnarchive = scheduleTask;
                break;
            }
        }
        if (taskToUnarchive == null) {
            throw new TaskNotFoundException("Task not Found");
        }
        taskToUnarchive.setArchived(false);
        userListRepository.save(user);
        return taskToUnarchive;


    }

    @Override
    public List<ScheduleTask> getArchivedTaskForUser(String userId) throws TaskNotFoundException, UserNotFoundException {
        List<ScheduleTask> archivedTasks = new ArrayList<>();
        Optional<User> userOptional = userListRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (user.getScheduleTaskList() != null) {
                for (ScheduleTask scheduleTask : user.getScheduleTaskList()) {
                    if (scheduleTask.isArchived() && !scheduleTask.isTrashed()) {
                        archivedTasks.add(scheduleTask);
                    }
                }
            }
        }
        return archivedTasks;
    }

    @Override
    public ScheduleTask trashed(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> scheduleTasks = user.getScheduleTaskList();
        if (scheduleTasks == null || scheduleTasks.isEmpty()) {
            throw new TaskNotFoundException("Task not Found");
        }
        ScheduleTask taskToTrash = null;
        for (ScheduleTask scheduleTask : scheduleTasks) {
            if (scheduleTask.getTaskId().equals(taskId)) {
                taskToTrash = scheduleTask;
                break;
            }
        }
        if (taskToTrash == null) {
            throw new TaskNotFoundException("Task not Found");
        }
        taskToTrash.setTrashed(true);
        userListRepository.save(user);
        return taskToTrash;
    }


    @Override
    public ScheduleTask restoreTaskFromTrash(String userId, String taskId) throws TaskNotFoundException, UserNotFoundException {
        Optional<User> optionalUser = userListRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with email: " + userId);
        }
        User user = optionalUser.get();
        List<ScheduleTask> scheduleTasks = user.getScheduleTaskList();
        if (scheduleTasks == null || scheduleTasks.isEmpty()) {
            throw new TaskNotFoundException("Task not Found");
        }
        ScheduleTask taskToRestore = null;
        for (ScheduleTask scheduleTask : scheduleTasks) {
            if (scheduleTask.getTaskId().equals(taskId)) {
                taskToRestore = scheduleTask;
                break;
            }
        }
        if (taskToRestore == null) {
            throw new TaskNotFoundException("Task not Found");
        }
        taskToRestore.setTrashed(false);
        userListRepository.save(user);
        return taskToRestore;

    }

    // In ListServiceImpl.java
    public List<ScheduleTask> getRestoredTasksForUser(String userId) throws UserNotFoundException {
        Optional<User> userOptional = userListRepository.findById(userId);
        if (!userOptional.isPresent()) {
            throw new UserNotFoundException("User not found with id: " + userId);
        }
        User user = userOptional.get();
        return user.getScheduleTaskList().stream()
                .filter(task -> !task.isArchived() && !task.isTrashed())
                .collect(Collectors.toList());
    }


    @Override
    public List<ScheduleTask> getTrashedTasks(String userId) throws Exception {
        List<ScheduleTask> trashedTasks = new ArrayList<>();
        Optional<User> userOptional = userListRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (user.getScheduleTaskList() != null) {
                for (ScheduleTask scheduleTask : user.getScheduleTaskList()) {
                    if (scheduleTask.isTrashed()) {
                        trashedTasks.add(scheduleTask);
                    }
                }
            }
        }
        return trashedTasks;
    }

    @Override
    public User getUserById(String userid) throws UserNotFoundException {
        Optional<User> userOptional = userListRepository.findById(userid);
        if (userOptional.isPresent()) {
            return userOptional.get();
        } else {
            String userId = null;
            throw new UserNotFoundException("User not found with email: " + userId);
        }
    }
}


