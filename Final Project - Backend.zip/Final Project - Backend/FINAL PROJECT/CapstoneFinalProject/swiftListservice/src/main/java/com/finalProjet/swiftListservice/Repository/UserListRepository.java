package com.finalProjet.swiftListservice.Repository;

import com.finalProjet.swiftListservice.Domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserListRepository extends MongoRepository<User,String> {

}
