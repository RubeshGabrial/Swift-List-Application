//package com.bej.authentication.service;
//
//import com.bej.authentication.domain.User;
//import com.bej.authentication.exception.UserAlreadyExistsException;
//import com.bej.authentication.exception.InvalidCredentialsException;
//import com.bej.authentication.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.Optional;
//
//@Service
//public class UserServiceImpl implements IUserService {
//
//    private final UserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
//
//    @Autowired
//    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//    @Override
//    public User saveUser(User user) {
//        log.debug("Saving new user with userId: {}", user.getUserId());
//        userRepository.findByUserId(user.getUserId())
//                .ifPresent(u -> {
//                    log.warn("User registration failed - User already exists with userId: {}", user.getUserId());
//                    throw new UserAlreadyExistsException("User already exists");
//                });
//        String encodedPassword = passwordEncoder.encode(user.getPassword());
//        log.debug("Encoded password for userId: {}", user.getUserId());
//        user.setPassword(encodedPassword);
//        User savedUser = userRepository.save(user);
//        log.debug("User saved successfully with userId: {}", savedUser.getUserId());
//        return savedUser;
//    }
//
//    @Override
//    public User getUserByUserIdAndPassword(String userId, String password) {
//        log.debug("Attempting to find user by userId: {}", userId);
//        Optional<User> optionalUser = userRepository.findByUserId(userId);
//
//        if (optionalUser.isPresent()) {
//            User user = optionalUser.get();
//            log.debug("User found with userId: {}. Validating password...", userId);
//
//            if (passwordEncoder.matches(password, user.getPassword())) {
//                log.info("User authenticated successfully with userId: {}", userId);
//                System.out.println("serviceimpl - login method");
//                return user;
//            } else {
//                log.warn("Invalid credentials provided for userId: {}", userId);
//                throw new InvalidCredentialsException("Invalid credentials");
//            }
//        } else {
//            log.warn("No user found with userId: {}", userId);
//            throw new InvalidCredentialsException("Invalid credentials");
//        }
//    }
//}

package com.bej.authentication.service;

import com.bej.authentication.domain.User;
import com.bej.authentication.exception.UserAlreadyExistsException;
import com.bej.authentication.exception.InvalidCredentialsException;
import com.bej.authentication.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

@Service
public class UserServiceImpl implements IUserService {

    private final UserRepository userRepository;
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) {
        log.debug("Saving new user with userId: {}", user.getUserId());
        userRepository.findByUserId(user.getUserId())
                .ifPresent(u -> {
                    log.warn("User registration failed - User already exists with userId: {}", user.getUserId());
                    throw new UserAlreadyExistsException("User already exists");
                });

        // Note: Password is being saved in plain text - not recommended for security reasons.
        User savedUser = userRepository.save(user);
        log.debug("User saved successfully with userId: {}", savedUser.getUserId());
        return savedUser;
    }

    @Override
    public User getUserByUserIdAndPassword(String userId, String password) {
        log.debug("Attempting to find user by userId: {}", userId);
        Optional<User> optionalUser = userRepository.findByUserId(userId);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            log.debug("User found with userId: {}. Validating password...", userId);

            // Directly comparing the plaintext passwords - not recommended.
            if (user.getPassword().equals(password)) {
                log.info("User authenticated successfully with userId: {}", userId);
                System.out.println("serviceimpl - login method");
                return user;
            } else {
                log.warn("Invalid credentials provided for userId: {}", userId);
                throw new InvalidCredentialsException("Invalid credentials");
            }
        } else {
            log.warn("No user found with userId: {}", userId);
            throw new InvalidCredentialsException("Invalid credentials");
        }
    }
}

