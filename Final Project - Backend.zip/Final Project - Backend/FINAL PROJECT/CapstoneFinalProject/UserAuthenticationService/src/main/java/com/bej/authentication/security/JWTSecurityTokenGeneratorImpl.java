//package com.bej.authentication.security;
//
//import com.bej.authentication.domain.User;
//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class JWTSecurityTokenGeneratorImpl implements SecurityTokenGenerator {
//
//    @Value("${jwt.secret}")
//    private String jwtSecret;
//
//    @Value("${jwt.expiration.time}")
//    private Long jwtExpirationInMillis;
//
//    @Override
//    public String createToken(User user) {
//        // Here you can include additional claims if needed
//        Map<String, Object> claims = new HashMap<>();
//        claims.put("userName", user.getUserName()); // Optionally add more information to the token
//
//        return Jwts.builder()
//                .setClaims(claims)
//                .setSubject(user.getUserId())
//                .setIssuedAt(new Date(System.currentTimeMillis()))
//                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationInMillis))
//                .signWith(SignatureAlgorithm.HS256, jwtSecret)
//                .compact();
//    }
//}


package com.bej.authentication.security;
import com.bej.authentication.domain.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
@Service
public class JWTSecurityTokenGeneratorImpl implements SecurityTokenGenerator {
    public String createToken(User user){
        // Write logic to create the Jwt
//       return generateToken(null, user.getUserId());
        Map<String,Object>claims = new HashMap<>();
        claims.put("userId",user.getUserId());
        String token = generateToken(claims, user.getUserId());
        return token;
    }
    public String generateToken(Map<String,Object> claims,String subject) {
        // Generate the token and set the user id in the claims
//         String jwtToken = null;
//         jwtToken= Jwts.builder()
//                .setSubject(subject)
//                .setIssuedAt(new Date())
//                .signWith(SignatureAlgorithm.HS256,"MyKey")
//                .compact();
//        return jwtToken;
        String jwtToken = Jwts.builder().setIssuer("Idea-Note")
                .setClaims(claims).setSubject(subject).setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256,"mysecret").compact();
        return jwtToken;
    }
}
