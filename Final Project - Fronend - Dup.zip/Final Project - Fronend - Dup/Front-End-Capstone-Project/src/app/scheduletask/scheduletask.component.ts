import { Component, OnDestroy, OnInit } from '@angular/core';
import { ScheduleTaskService } from '../services/scheduletask.service';
import { ScheduledTask } from '../model/scheduledtask';
import { Router } from '@angular/router'; // Import the Router
import { ReactiveFormsModule } from '@angular/forms';
import { TaskNotificationService } from '../services/task-notification.service';
import { Subscription, interval, startWith, switchMap } from 'rxjs';



@Component({
  selector: 'app-scheduletask',
  templateUrl: './scheduletask.component.html',
  styleUrls: ['./scheduletask.component.css']
})
export class ScheduleTaskComponent implements OnInit, OnDestroy {  // Ensure that OnInit is properly implemented

  scheduledTasks: ScheduledTask[] = [];
  // tomorrow = new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split('T')[0];
  today = new Date().toISOString().split('T')[0];
  private updateSubscription?: Subscription;


  constructor(
    private scheduleTaskService: ScheduleTaskService,
    private router: Router,
    private taskNotificationService: TaskNotificationService,
  ) {}

  ngOnInit(): void {
    // Subscribe to task updates to refresh the list of tasks
    this.taskNotificationService.tasksUpdated.subscribe(() => {
      this.loadScheduledTasks();
    });
  
    // Initial load of scheduled tasks
    this.loadScheduledTasks();
  }

  ngOnDestroy(): void {
    // Clean up the subscription
    if (this.updateSubscription) {
      this.updateSubscription.unsubscribe();
    }
  }

  private refreshTasks(): void {
    this.scheduleTaskService.getAllScheduledTasks().subscribe({
      next: (tasks) => this.scheduledTasks = tasks,
      error: (error) => console.error('Error refreshing tasks', error)
    });
  }

  addTask(): void {
    // Initialize all properties based on ScheduledTask interface
    this.scheduledTasks.push({
      taskName: '',
      date: this.today,
      sTime: '',
      sNote: '',
      taskPriority: 'Low' // Default priority, as backend sets "Low" if not provided
    });
  }

  removeTask(index: number): void {
    const task = this.scheduledTasks[index];
    if (task.taskId) {
      this.scheduleTaskService.deleteScheduledTask(task.taskId).subscribe({
        next: response => console.log('Task deleted successfully', response),
        error: error => console.error('Error deleting task', error)
      });
    }
    this.scheduledTasks.splice(index, 1);
  }



  saveTasks(): void {
    // Use a counter to track the number of save/update operations completed
    let operationsCompleted = 0;
    const totalOperations = this.scheduledTasks.length;
  
    this.scheduledTasks.forEach(task => {
      if (task.taskId) {
        // Update existing task
        this.scheduleTaskService.updateScheduledTask(task.taskId, task).subscribe({
          next: response => {
            console.log('Task updated successfully', response);
            operationsCompleted++;
            if (operationsCompleted === totalOperations) {
              this.finalizeSave();
            }
          },
          error: error => {
            console.error('Error updating task', error);
            operationsCompleted++;
            if (operationsCompleted === totalOperations) {
              this.finalizeSave();
            }
          }
        });
      } else {
        // Save new task
        this.scheduleTaskService.saveScheduledTask(task).subscribe({
          next: response => {
            console.log('Task saved successfully', response);
            operationsCompleted++;
            if (operationsCompleted === totalOperations) {
              this.finalizeSave();
            }
          },
          error: error => {
            console.error('Error saving task', error);
            operationsCompleted++;
            if (operationsCompleted === totalOperations) {
              this.finalizeSave();
            }
          }
        });
      }
    });
  }
  
  finalizeSave(): void {
    // Clear the array
    this.scheduledTasks = [];
  }
  



  loadScheduledTasks(): void {
    this.scheduleTaskService.getAllScheduledTasks().subscribe({
      next: (tasks) => {
        // Assign all tasks directly without filtering
        this.scheduledTasks = tasks;
      },
      error: (error) => {
        console.error('Error loading scheduled tasks:', error);
      }
    });
  }
  

  viewSavedTasks(): void {
    this.router.navigate(['/display-scheduled-tasks']);
  }


  navigateBack() {
    this.router.navigate(['/schedule-task']);
  }
}
