// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { ScheduletaskComponent } from './scheduletask.component';

// describe('ScheduletaskComponent', () => {
//   let component: ScheduletaskComponent;
//   let fixture: ComponentFixture<ScheduletaskComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ScheduletaskComponent]
//     })
//     .compileComponents();
    
//     fixture = TestBed.createComponent(ScheduletaskComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
