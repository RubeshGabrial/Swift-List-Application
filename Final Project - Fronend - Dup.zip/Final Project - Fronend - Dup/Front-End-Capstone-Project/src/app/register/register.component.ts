import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { RegisterService } from '../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user: User = {
    userName: '',
    userId: '', 
    password: '',
    gender: '',
    contactNumber: '',
    myDayList: [] 
  };
  isSubmitting = false;
  registrationSuccess = false; 
  alreadyRegistered = false;

  constructor(private registerService: RegisterService, private router: Router) {}

  onSubmit() {
    this.isSubmitting = true;
    this.registerService.register(this.user).subscribe({
      next: (response) => {
        console.log('Registration successful', response);
        this.isSubmitting = false;
        this.registrationSuccess = true;

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 3000);
      },
      error: (error) => {
        this.isSubmitting = false;
        if (error.status === 409) { // Assuming 409 status code for duplicate registration
          this.alreadyRegistered = true; // Set the flag to true if user is already registered
        } else {
          console.error('Registration error', error);
        }
      }
    });
  }
}
