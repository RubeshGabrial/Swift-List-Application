import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { ScheduledTask } from '../model/scheduledtask';

@Injectable({
  providedIn: 'root'
})
export class ArchiveService {
  private baseUrl = 'http://localhost:9000/api/v2'; 

  constructor(private http: HttpClient) { }

  archiveScheduledTask(taskId: string): Observable<ScheduledTask> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getAuthToken()}` // Replace with actual method to retrieve the token
    });
    return this.http.put<ScheduledTask>(`${this.baseUrl}/user/archive/${taskId}`, {}, { headers });
  }

  private getAuthToken(): string {
    const token = localStorage.getItem('authToken');
    if (token === null) {
      throw new Error('Authentication token is not set');
    }
    return token;
  }

  getArchivedTasks(): Observable<ScheduledTask[]> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getAuthToken()}`
    });
    return this.http.get<ScheduledTask[]>(`${this.baseUrl}/user/getArchive`, { headers });
  }

  deletePermanently(taskId: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getAuthToken()}`
    });
    return this.http.delete(`${this.baseUrl}/user/scheduleList/${taskId}`, { headers });
  }

  restoreArchivedTask(taskId: string): Observable<ScheduledTask> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.getAuthToken()}`
    });
    
    // Call to restore the task
    return this.http.put<ScheduledTask>(`${this.baseUrl}/user/unArchive/${taskId}`, {}, { headers })
      .pipe(
        tap(() => {
          // Optional: If you want to automatically refresh the archived tasks list upon restore
          this.getArchivedTasks().subscribe();
        })
      );
  }
  
  
}
