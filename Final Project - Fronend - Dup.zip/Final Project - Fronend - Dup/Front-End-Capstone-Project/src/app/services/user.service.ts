import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  authAppBaseUrl = "http://localhost:8083/api/v1";
  productAppBaseUrl = "http://localhost:8087/api/v2";

  save(signUpUserAuthData:any){
    return this.httpClient.post(this.authAppBaseUrl+"/save",signUpUserAuthData);
  }
  register(signUpUserProductData:any) {
    return this.httpClient.post(this.productAppBaseUrl+"/register",signUpUserProductData);
  }

  getUserDetails(){
    let httpHeaders=new HttpHeaders({
      "authorization":'Bearer ' + localStorage.getItem("token"),
    });
    let requestOptions={headers:httpHeaders};
    this.httpClient.get(this.productAppBaseUrl+"/getUserDetails",requestOptions);



  }
}
