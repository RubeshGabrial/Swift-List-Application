import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ScheduledTask } from '../model/scheduledtask';
import { AuthService } from './auth.service'; // Make sure to import AuthService



@Injectable({
  providedIn: 'root'
})
export class ScheduleTaskService {
  private apiUrl = 'http://localhost:9000/api/v2'; 

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHttpOptions(): { headers: HttpHeaders } {
    // Get the token from AuthService
    const token = this.authService.getToken();
    // Check if the token is present
    if (!token) {
      throw new Error('Authentication token not found');
    }
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` // Set the Authorization header with the token
      })
    };
  }

  // Methods would now include headers with the token
  saveScheduledTask(task: ScheduledTask): Observable<ScheduledTask> {
    return this.http.post<ScheduledTask>(`${this.apiUrl}/user/scheduleList`, task, this.getHttpOptions());
  }

  updateScheduledTask(taskId: string, task: ScheduledTask): Observable<ScheduledTask> {
    return this.http.put<ScheduledTask>(`${this.apiUrl}/user/scheduleList/${taskId}`, task, this.getHttpOptions());
  }

  deleteScheduledTask(taskId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/user/scheduleList/${taskId}`, this.getHttpOptions());
  }

  getAllScheduledTasks(): Observable<ScheduledTask[]> {
    return this.http.get<ScheduledTask[]>(`${this.apiUrl}/user/tasks`, this.getHttpOptions());
  }

  unarchiveTask(taskId: string): Observable<ScheduledTask> {
    return this.http.put<ScheduledTask>(`${this.apiUrl}/user/unArchive/${taskId}`, {}, this.getHttpOptions());
  }

}
