import { TestBed } from '@angular/core/testing';

import { TaskNotificationService } from './task-notification.service';

describe('TaskNotificationService', () => {
  let service: TaskNotificationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TaskNotificationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
