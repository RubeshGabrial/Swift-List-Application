import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task } from '../model/task'; // Make sure the path to your model is correct

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private apiUrl = 'http://localhost:9000/api/v2/user'; // Your actual backend endpoint

  constructor(private http: HttpClient) { }

  // Fetch all tasks for a given user
  getTasks(userId: string): Observable<Task[]> {
    const endpoint = `${this.apiUrl}/${userId}/tasks`;
    return this.http.get<Task[]>(endpoint);
  }

  // Save a new task for a given user
  saveTask(userId: string, task: Task): Observable<Task> {
    const endpoint = `${this.apiUrl}/${userId}/addList`;
    console.log("Saving task...");
    return this.http.post<Task>(endpoint, task);
  }

  // Update an existing task for a given user
  updateTask(userId: string, task: Task): Observable<Task> {
    const endpoint = `${this.apiUrl}/${userId}/tasks/${task.id}`;
    console.log("Updating task...");
    return this.http.put<Task>(endpoint, task);
  }

  // Delete a task for a given user
  deleteTask(userId: string, taskId: string): Observable<any> {
    const endpoint = `${this.apiUrl}/${userId}/tasks/${taskId}`;
    console.log("Deleting task...");
    return this.http.delete(endpoint);
  }
}
