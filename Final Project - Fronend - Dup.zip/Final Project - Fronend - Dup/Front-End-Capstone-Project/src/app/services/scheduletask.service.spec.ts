import { TestBed } from '@angular/core/testing';

import { ScheduletaskService } from './scheduletask.service';

describe('ScheduletaskService', () => {
  let service: ScheduletaskService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScheduletaskService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
