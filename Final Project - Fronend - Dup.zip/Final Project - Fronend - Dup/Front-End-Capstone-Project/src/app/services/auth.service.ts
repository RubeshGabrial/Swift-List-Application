


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedInUserSubject = new BehaviorSubject<string | null>(null);
  loggedInUser$ = this.loggedInUserSubject.asObservable();
  private loggedInUserNameSubject = new BehaviorSubject<string | null>(null);
  loggedInUserName$ = this.loggedInUserNameSubject.asObservable();
  private authTokenKey: string = 'authToken'; // use 'authToken' consistently


  constructor(private http: HttpClient) {}

  login(userData: { userId: string; password: string }): Observable<any> {
    return this.http.post<any>('http://localhost:9000/api/v1/login', userData).pipe(
      tap((response: { userName: string; token: string; userId: string }) => {
        console.log('Login successful, userName:', response.userName);
        // Include the token in the call to setLoggedInUser
        this.setLoggedInUser(response.userId, response.userName, response.token);
      })
    );
  }
  

  setLoggedInUser(userId: string, userName: string, token: string): void {
    localStorage.setItem('userId', userId);
    localStorage.setItem('userName', userName);
    localStorage.setItem(this.authTokenKey, token);
    this.loggedInUserSubject.next(userId);
    this.loggedInUserNameSubject.next(userName);
  }

  getLoggedInUserName(): string | null {
    return localStorage.getItem('userName'); 
  }

  getCurrentUserId(): string | null {
    return localStorage.getItem('userId');
  }

  logout(): void {
    // Clear local storage and notify subscribers of the change
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    localStorage.removeItem(this.authTokenKey);
    this.loggedInUserSubject.next(null);
    this.loggedInUserNameSubject.next(null);
  }

  storeToken(token: string): void {
    localStorage.setItem(this.authTokenKey, token); // Store using the authTokenKey
  }

    isLoggedIn(): boolean {
    const authToken = this.getToken();
    return !!authToken; 
  }

  getToken(): string | null {
    return localStorage.getItem(this.authTokenKey); // Retrieve using the authTokenKey
  }
}
