import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ScheduledTask } from '../model/scheduledtask';

@Injectable({
  providedIn: 'root'
})
export class TaskSyncService {
  private taskRefreshSource = new BehaviorSubject<string | null>(null);
  taskRefreshNeeded$ = this.taskRefreshSource.asObservable();

  constructor() {}

  notifyTaskChange(taskId: string) {
    this.taskRefreshSource.next(taskId); // Emit the ID of the task that was changed
  }

  // If you need to signal a general refresh without specifying a task, you could use:
  notifyRefreshNeeded() {
    this.taskRefreshSource.next(null);
  }
}
