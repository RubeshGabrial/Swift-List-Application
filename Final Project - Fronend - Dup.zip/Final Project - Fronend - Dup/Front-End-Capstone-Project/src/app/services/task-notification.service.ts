import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TaskNotificationService {
  private _tasksUpdated = new BehaviorSubject<boolean>(false);

  get tasksUpdated() {
    return this._tasksUpdated.asObservable();
  }

  notifyTaskUpdate() {
    this._tasksUpdated.next(true);
  }
}
