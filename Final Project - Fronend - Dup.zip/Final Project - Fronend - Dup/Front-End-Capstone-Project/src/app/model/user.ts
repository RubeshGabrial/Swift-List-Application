import { Task } from "./task";

export interface User {
  userName: string;
  userId: string;
  password: string;
  gender: string;
  contactNumber: string;
  myDayList: Task[]; 
}
