

export interface Task {
  id: string;
  note: string;
  time: string; 
}
