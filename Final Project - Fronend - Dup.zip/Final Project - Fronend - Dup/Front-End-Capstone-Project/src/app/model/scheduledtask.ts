export interface ScheduledTask {
  taskId?: string;  
  taskName: string;
  date: string | null;     // Allow null
  sTime: string | null;    // Allow null
  sNote: string;
  taskPriority: string;
  isArchived?: boolean; // Add this line if the property is optional
}
