import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service'; // Adjust the import path as necessary
import { Task } from '../model/task'; // Adjust the path as necessary
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-my-day',
  templateUrl: './my-task.component.html',
  styleUrls: ['./my-task.component.css']
})
export class MyDayComponent implements OnInit {
  tasks: Task[] = [];
  currentUserId: string = '';
  isUserLoggedIn: boolean = false; // Added flag

  constructor(private taskService: TaskService, private authService: AuthService) {}

  ngOnInit() {
    this.authService.loggedInUser$.subscribe((userId: string | null) => {
      this.currentUserId = userId ? userId : '';
      this.isUserLoggedIn = !!userId; // Update flag based on userId presence
    });
  }

  addTask(note: string, time: string): void {
    const newId = this.generateUniqueId();
    this.tasks.push({ id: newId, note, time }); // Now requires time to be passed
  }

  private generateUniqueId(): string {
    return Date.now().toString(); // Simple example, consider using a more unique ID generator
  }

  deleteTask(index: number): void {
    if (this.tasks.length > 0) {
      this.tasks.splice(index, 1);
    }
  }

  saveTasks(): void {
    if (this.isUserLoggedIn) { // Use flag to check if user is logged in
      this.tasks.forEach(task => {
        this.taskService.saveTask(this.currentUserId, task).subscribe({
          next: (response) => console.log('Task saved successfully', response),
          error: (error) => console.error('Error saving task', error)
        });
      });
    } else {
      console.error('No current user ID set');
      // Handle the lack of a user ID appropriately
    }
  }

}
