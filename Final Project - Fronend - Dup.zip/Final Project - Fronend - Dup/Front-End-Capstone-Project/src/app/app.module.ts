import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component'; 
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MyDayComponent } from './my-task/my-task.component';
import { ScheduleTaskComponent } from './scheduletask/scheduletask.component';
import { AGetStartedComponent } from './a-get-started/a-get-started.component';
import { DisplayScheduledTaskComponent } from './display-scheduledtask/display-scheduledtask.component';
import { CommonModule } from '@angular/common'; // Make sure this is imported
import { DatePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ArchiveComponent } from './archive/archive.component';





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent, 
    DashboardComponent, 
    LoginComponent, 
    RegisterComponent, 
    MyDayComponent, 
    ScheduleTaskComponent, 
    AGetStartedComponent, 
    DisplayScheduledTaskComponent, 
    ArchiveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule ,
    FormsModule,
    HttpClientModule,
    CommonModule,
    ReactiveFormsModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
