import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegisterComponent } from './register/register.component';
import { MyDayComponent } from './my-task/my-task.component'; // Import MyTaskComponent
import { ScheduleTaskComponent } from './scheduletask/scheduletask.component'; // Import ScheduleTaskComponent
import { AGetStartedComponent } from './a-get-started/a-get-started.component';
import { DisplayScheduledTaskComponent } from './display-scheduledtask/display-scheduledtask.component'; // Adjust the path as needed
import { ArchiveComponent } from './archive/archive.component';
import { AuthGuard } from './guards/auth.guard';


const routes: Routes = [
  { path: '', redirectTo: 'get-started', pathMatch: 'full' }, // Corrected redirection
  // { path: 'get-started', component: AGetStartedComponent }, 
  {
    path: 'get-started',
    component: AGetStartedComponent,
  },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'my-day', component: MyDayComponent },
  { path: 'schedule-task', component: ScheduleTaskComponent,canActivate: [AuthGuard] },
  { path: 'display-scheduled-tasks', component: DisplayScheduledTaskComponent, canActivate: [AuthGuard] }, 
  { path: 'archive', component: ArchiveComponent, canActivate: [AuthGuard] }, 

]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
