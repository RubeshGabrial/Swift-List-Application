

import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loggedInUserId: string | null = null;
  loggedInUserName: string | null = null;
  private subscriptions: Subscription[] = [];

  constructor(private authService: AuthService, private router: Router, private changeRef: ChangeDetectorRef) {}

  ngOnInit() {
    const userSub = this.authService.loggedInUser$.subscribe(userId => {
      console.log('User ID updated:', userId);
      this.loggedInUserId = userId;
      if (!userId) {
        this.loggedInUserName = null; // Clear the username if the user ID is not present
        this.changeRef.detectChanges();  // Manually trigger change detection
      }
    });
    const userNameSub = this.authService.loggedInUserName$.subscribe(userName => {
      console.log('User Name updated:', userName);
      this.loggedInUserName = userName;
      this.changeRef.detectChanges(); 
    });

    this.subscriptions.push(userSub, userNameSub);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe()); 
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']); 
  }
}
