

import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ScheduleTaskService } from '../services/scheduletask.service';
import { ScheduledTask } from '../model/scheduledtask';
import { HttpErrorResponse } from '@angular/common/http';  // Import this for HTTP error response typing
import { ArchiveService } from '../services/archive.service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { TaskSyncService } from '../services/task-sync.service'; 

@Component({
  selector: 'app-display-scheduled-task',
  templateUrl: './display-scheduledtask.component.html',
  styleUrls: ['./display-scheduledtask.component.css']
})
export class DisplayScheduledTaskComponent implements OnInit {
  private tasksSubscription: Subscription = new Subscription();
  
  tasks: ScheduledTask[] = [];
  filteredTasks: ScheduledTask[] = [];
  searchControl = new FormControl();
  searchTerm: string = '';
  private tasksSource = new BehaviorSubject<ScheduledTask[]>([]);
  
  // tasks$ = this.tasksSource.asObservable();

  constructor(
    private scheduleTaskService: ScheduleTaskService,
    private archiveService: ArchiveService,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private taskSyncService: TaskSyncService, 
  ) {}

  ngOnInit(): void {
    this.fetchTasks();
    this.setupSearch();
    this.taskSyncService.taskRefreshNeeded$.subscribe(() => {
      this.fetchTasks(); 
    });
  }

  ngOnDestroy(): void {
    if (this.tasksSubscription) {
      this.tasksSubscription.unsubscribe();
    }
  }

  fetchTasks(priority: string = 'all'): void {
    this.scheduleTaskService.getAllScheduledTasks().subscribe(
      (tasksFromService) => {
        let tasks = tasksFromService;
        
        if (priority !== 'all') {
          tasks = tasks.filter(task => task.taskPriority === priority);
        }
        
        this.tasks = tasks.filter(task => !task.isArchived);
        this.filteredTasks = this.tasks;
        
        this.applyFilters();
      },
      (error: HttpErrorResponse) => {
        console.error('Error fetching tasks:', error.message);
      }
    );
  }

  private refreshTaskList(): void {
    this.fetchTasks();
  }


  
  
  applyFilters(): void {
    // First filter by the search term if it's present
    let filteredBySearch = this.searchTerm ?
      this.tasks.filter(task => task.taskName.toLowerCase().includes(this.searchTerm.toLowerCase())) :
      [...this.tasks]; // If no search term, copy all tasks
  
    this.filteredTasks = filteredBySearch;
  }
  
  searchTask(event: any): void {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.applyFilters(); // Apply both search and any other filters
  }


  setupSearch(): void {
    this.searchControl.valueChanges.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(term => {
      this.filterTasks(term);
    });
  }
  filterTasks(searchTerm: string): void {
    if (!searchTerm) {
      this.filteredTasks = [...this.tasks];
    } else {
      this.filteredTasks = this.tasks.filter(task =>
        task.taskName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
  }


  editTask(id?: string): void {
    if (!id) {
      console.error('No task ID provided for editing.');
      return;
    }
  }
  

  navigateBack(extras = {}) {
    this.router.navigate(['/schedule-task'], extras);
  }

  
  sortTasksByPriority(event: Event): void {
    const element = event.target as HTMLSelectElement;
    const priority = element.value;
    this.fetchTasks(priority);
  
    // Update the selected option visually (optional)
    element.selectedOptions[0].selected = true; // Assuming a single select element
  }
  
  archiveTask(taskId: string): void {
    if (!taskId) {
      console.error('No task ID provided for archiving.');
      return;
    }
    console.log('Attempting to archive task with ID:', taskId);
  
    this.archiveService.archiveScheduledTask(taskId).subscribe({
      next: (archivedTask) => {
        this.tasks = this.tasks.filter(task => task.taskId !== archivedTask.taskId);
        this.filteredTasks = this.filteredTasks.filter(task => task.taskId !== archivedTask.taskId);
        this.cdr.detectChanges();
        console.log(`Task with ID ${taskId} archived`);
      },
      error: (error) => {
        console.error('Error archiving task:', error);
        // Display an error message to the user (e.g., using a toast notification)
      }
    });
  }
  
  navigateToArchive(filter?: string): void {
    const navigationExtras = filter ? { queryParams: { filter } } : {};
    this.router.navigate(['/archive'], navigationExtras);
  }

  getPriorityClass(priority: string): string {
    switch (priority) {
      case 'High': return 'high-priority';
      case 'Medium': return 'medium-priority';
      case 'Low': return 'low-priority';
      default: return ''; // Handle unexpected priorities gracefully
    }
  }
}
