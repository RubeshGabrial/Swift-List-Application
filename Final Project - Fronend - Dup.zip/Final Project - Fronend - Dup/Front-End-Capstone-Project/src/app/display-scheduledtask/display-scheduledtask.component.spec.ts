// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { DisplayScheduledtaskComponent } from './display-scheduledtask.component';

// describe('DisplayScheduledtaskComponent', () => {
//   let component: DisplayScheduledtaskComponent;
//   let fixture: ComponentFixture<DisplayScheduledtaskComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [DisplayScheduledtaskComponent]
//     })
//     .compileComponents();
    
//     fixture = TestBed.createComponent(DisplayScheduledtaskComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
