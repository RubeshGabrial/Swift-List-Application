// login.component.ts

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  user = { userId: '', password: '' };

  constructor(private authService: AuthService, private router: Router) {}


  onSubmit() {
    // this.authService.login(this.user).subscribe({
    //   next: (response) => {
    //     console.log('Logged in Successfully', response);
    //     this.authService.setLoggedInUser(response.userId, response.userName); // Set logged in user
    //     this.router.navigate(['/dashboard']);
    //   },
    //   error: (error) => {
    //     console.error('Login error', error);
    //     if (error.status === 401) {
    //       alert("Invalid email or password. Please try again.");
    //     }
    //   }
    // });

    this.authService.login(this.user).subscribe({
      next: (response) => {
        console.log('Logged in Successfully', response);
        // Update this call to include the response token
        this.authService.setLoggedInUser(response.userId, response.userName, response.token);
        this.router.navigate(['/dashboard']);
      },
      error: (error) => {
        console.error('Login error', error);
        if (error.status === 401) {
          alert("Invalid email or password. Please try again.");
        }
      }
    });
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  getUserName(): string | null {
    return this.authService.getLoggedInUserName();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']); // Navigate to the login page or wherever appropriate
  }
}




