import { Component } from '@angular/core';

@Component({
  selector: 'app-a-get-started',
  templateUrl: './a-get-started.component.html',
  styleUrl: './a-get-started.component.css'
})
export class AGetStartedComponent {

}
