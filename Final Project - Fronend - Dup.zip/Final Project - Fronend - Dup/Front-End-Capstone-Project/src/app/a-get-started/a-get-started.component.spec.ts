import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AGetStartedComponent } from './a-get-started.component';

describe('AGetStartedComponent', () => {
  let component: AGetStartedComponent;
  let fixture: ComponentFixture<AGetStartedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AGetStartedComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AGetStartedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
