import { Component, OnInit } from '@angular/core';
import { ArchiveService } from '../services/archive.service';
import { ScheduledTask } from '../model/scheduledtask'; // Assuming you have this type defined
import { Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { TaskSyncService } from '../services/task-sync.service';
import { TaskNotificationService } from '../services/task-notification.service';


@Component({
  selector: 'app-archive',
  templateUrl: './archive.component.html',
  styleUrls: ['./archive.component.css']
})
export class ArchiveComponent implements OnInit {
  archivedTasks: ScheduledTask[] = [];
  filteredTasks: ScheduledTask[] = [];  // Now declared


  constructor(private archiveService: ArchiveService,    private router: Router, private ref: ChangeDetectorRef, 
    private taskSyncService: TaskSyncService,
    private taskNotificationService:TaskNotificationService
  ) {}

  ngOnInit(): void {
    this.fetchArchivedTasks();
    
  }


  fetchArchivedTasks(): void {
    this.archiveService.getArchivedTasks().subscribe(
      tasks => {
        console.log('Received archived tasks:', tasks);
        this.archivedTasks = tasks;
      },
      error => console.error('Error fetching archived tasks:', error)
    )
  }

  restoreTask(taskId: string): void {
    if (!taskId) {
      console.error('No task ID provided for restoration.');
      return;
    }
  
    this.archiveService.restoreArchivedTask(taskId).subscribe({
      next: () => {
    
        const taskIndex = this.archivedTasks.findIndex(task => task.taskId === taskId);
        if (taskIndex !== -1) {
          this.archivedTasks.splice(taskIndex, 1);
          this.ref.detectChanges(); 
        }
        
        this.taskNotificationService.notifyTaskUpdate();
  
        console.log(`Task ${taskId} restored successfully`);
      },
      error: (error) => {
        console.error('Error restoring task:', error);
        this.fetchArchivedTasks();
      }
    });
  }
  

trackByTasks(index: number, task: ScheduledTask): string | undefined {
  return task.taskId;
}
  

  viewSavedTasks(): void {
    this.router.navigate(['/display-scheduled-tasks']);
  }

  getPriorityClass(priority: string): string {
    switch (priority) {
      case 'High':
        return 'high-priority';
      case 'Medium':
        return 'medium-priority';
      case 'Low':
        return 'low-priority';
      default:
        return '';
    }
  }


  

  deletePermanently(taskId: string | undefined): void {
    if (!taskId) {
      console.error('No task ID provided for deletion.');
      return;
    }
    this.archiveService.deletePermanently(taskId).subscribe({
      next: (response) => {
        console.log('Deleting task permanently:', taskId);
        this.archivedTasks = this.archivedTasks.filter(task => task.taskId !== taskId);
      },
      error: (error) => {
        console.error('Error deleting task:', error);
      }
    });
  }
}
